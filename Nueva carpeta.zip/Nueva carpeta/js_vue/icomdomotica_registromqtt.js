
const registro_mqtt = new Vue({
    el: '#modalMqtt',
    data: {
        mqtt: {
            usuario: null,
            clave: null,
            claveconf: null
        },
        respuesta: []
    },
    computed: {
        isFormEmpty: function () {
            return !(this.mqtt.usuario && this.mqtt.clave && this.mqtt.claveconf);
        }
    },
    methods: {
        onSubmit: function () {
            this.$http.post('nuevo_mqtt', this.mqtt).then(response => {
                this.respuesta = response.body;
                if (this.respuesta.estatus === 'OK') {
                    $('#modalMqtt').modal('hide');
                    this.$swal({
                        title: "",
                        text: this.respuesta.mensaje,
                        icon: "success"
                    });
                } else {
                    $('#modalMqtt').modal('hide');
                    this.$swal({
                        title: "",
                        text: this.respuesta.mensaje,
                        icon: "error"
                    });
                }
            }, error => {
                $('#modalMqtt').modal('hide');
                this.$swal({
                    title: "Error desconocido",
                    text: error.body,
                    icon: "error"
                });
            });
            this.mqtt.usuario = null;
            this.mqtt.clave = null;
            this.mqtt.claveconf = null;
        }
    }
});
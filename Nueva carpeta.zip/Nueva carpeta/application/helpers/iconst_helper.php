<?php

class iconst_helper {
    
    const ESTATUS = "estatus";
    const MENSAJE = "mensaje";
    
    const OK = "OK";
    const EXISTE = "EXISTE";
    const NA = "NA";
    const ERROR = "ERROR";

    const SESSION_INIT = "SESSION_INIT";
    const SESSION_NULL = "SESSION_NULL";
    
    const USUARIO_INVITADO = "usuario";
    const USUARIO_ADMINISTRADOR = "administrador";
    
    public function __construct() {}
}
